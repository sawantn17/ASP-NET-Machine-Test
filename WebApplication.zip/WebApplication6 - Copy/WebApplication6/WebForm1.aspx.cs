﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-90LK0PJK;Initial Catalog=programingdb;User ID=sa;Password=admin123");
        SqlCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

    

        protected void btnReset_Click(object sender, EventArgs e)
        {
            {
                clear();
            }

        }

        private void clear()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";


        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                cmd = new SqlCommand("insert into Productinfo_Tab values ('" + Convert.ToInt32(TextBox1.Text) + "','" + TextBox2.Text + "','" + Convert.ToInt32(TextBox3.Text) + "','" + TextBox4.Text + "')", con);
                cmd.ExecuteNonQuery();
                Label1.Text = "Record inserted..";
                con.Close();
                LoadRecord();
                clear();

            }
            catch (Exception e1)
            {
                Response.Write(e1.Message);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("update Productinfo_Tab set   ProductName=@ProductName,CategoryId=@CategoryId,CategoryName=@CategoryName where ProductId='"+TextBox1.Text+"'", con);
                //cmd.Parameters.AddWithValue("@ProductId", Convert.ToInt32(TextBox1.Text));
                cmd.Parameters.AddWithValue("@ProductName", TextBox2.Text);
                cmd.Parameters.AddWithValue("@CategoryId", Convert.ToInt32(TextBox3.Text));
                cmd.Parameters.AddWithValue("@CategoryName", TextBox4.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                Label1.Text = "Record Updated....";
                LoadRecord();
                clear();

            }
            catch (Exception e1)
            {
                Response.Write(e1.Message);
            }
        }

        void LoadRecord()
        {
            con.Open();
            SqlCommand comm = new SqlCommand("select * from Productinfo_Tab", con);
            SqlDataAdapter d = new SqlDataAdapter(comm);
            DataTable dt = new DataTable();
            d.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            con.Close();

        }
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("delete from Productinfo_Tab where ProductId='" + TextBox1.Text + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Label1.Text = "Record deleted...";
            }
            catch (Exception e1)
            {
                Response.Write(e1.Message);
            }

        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("select * from Productinfo_Tab ", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                con.Close();
            }
            catch (Exception e1)
            {
                Response.Write(e1.Message);
            }
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            LoadRecord();
        }
    }
    
}       
